package com.example.basicbankingapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.basicbankingapp.data.Person;
import com.example.basicbankingapp.R;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.PersonViewHolder> {
    ArrayList names ,emails,currentBalances,imges ,id;
    ArrayList <Person> persons;
    private OnRecyclerViewItemClickListener listener;
    public CustomAdapter(ArrayList names,ArrayList emails ,ArrayList currentBalances,ArrayList imges ,ArrayList id,OnRecyclerViewItemClickListener listener){
        this.names = names;
        this.emails = emails;
        this.currentBalances = currentBalances;
        this.imges = imges;
        this.id=id;
        this.listener=listener;
    }

    @NonNull
    @Override
    public CustomAdapter.PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v =LayoutInflater.from(parent.getContext()).inflate(R.layout.coustem_item_view, null, false);
        PersonViewHolder viewHolder = new PersonViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.PersonViewHolder holder, int position) {

        holder.profileImage.setImageResource((Integer) imges.get(position));
        holder.profileName.setText(names.get(position)+"");
        holder.currentBalanceText.setText(currentBalances.get(position)+"");

    }

    @Override
    public int getItemCount() {
        return names.size();
    }

    public class PersonViewHolder extends RecyclerView.ViewHolder {
        ImageView profileImage;
        TextView profileName;
        TextView currentBalanceText;
        public PersonViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImage = itemView.findViewById(R.id.main_screen_profile_image);
            profileName = itemView.findViewById(R.id.main_screen_profile_name);
            currentBalanceText = itemView.findViewById(R.id.main_screen_profile_tv_current_balance);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int p =getAdapterPosition();
                    listener.onItemClick(p);
                }
            });
        }
    }
}