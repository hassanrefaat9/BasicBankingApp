package com.example.basicbankingapp.adapter;

public interface OnRecyclerViewItemClickListener {
    void onItemClick(int position);

}
