package com.example.basicbankingapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.basicbankingapp.R;

import java.util.ArrayList;

public class ShowTransfersAdapter
    extends RecyclerView.Adapter<ShowTransfersAdapter.ShowTransfersHolder> {
  ArrayList name, email, money;

  public ShowTransfersAdapter(ArrayList name, ArrayList email, ArrayList money) {
    this.name = name;
    this.email = email;
    this.money = money;
  }

  @NonNull
  @Override
  public ShowTransfersAdapter.ShowTransfersHolder onCreateViewHolder(
      @NonNull ViewGroup parent, int viewType) {
    View v =
        LayoutInflater.from(parent.getContext()).inflate(R.layout.show_itrem_transfer, parent, false);
    ShowTransfersHolder viewHolder = new ShowTransfersHolder(v);

    return viewHolder;
  }

  @Override
  public void onBindViewHolder(@NonNull ShowTransfersAdapter.ShowTransfersHolder holder, int position) {
    holder.tv_name.setText(name.get(position)+"");
    holder.tv_email.setText(email.get(position) + "");
    holder.tv_money.setText(money.get(position)+ "");
  }

  @Override
  public int getItemCount() {
    return name.size();
  }

  public class ShowTransfersHolder extends RecyclerView.ViewHolder {
    TextView tv_name, tv_email, tv_money;

    public ShowTransfersHolder(@NonNull View itemView) {
      super(itemView);
      tv_name = itemView.findViewById(R.id.showtransfers_tv_name);
      tv_email = itemView.findViewById(R.id.showtransfers_tv_email);
      tv_money = itemView.findViewById(R.id.showtransfers_tv_money);
    }
  }
}
