package com.example.basicbankingapp.data;

public class Person {
    private String name;
    private int currentBalance;
    private String email;
    private int img;
    private int id;
    public String getEmail() {
        return email;
    }

    public Person(String name, int currentBalance, String email) {
        this.name = name;
        this.currentBalance = currentBalance;
        this.email = email;
    }

    public Person(String name, int currentBalance, int img, String email) {
        this.name = name;
        this.currentBalance = currentBalance;
        this.img = img;
        this.email = email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Person(String name, int currentBalance) {
        this.name = name;
        this.currentBalance = currentBalance;
    }

    public Person(String name, int currentBalance, int img) {
        this.name = name;
        this.currentBalance = currentBalance;
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(int currentBalance) {
        this.currentBalance = currentBalance;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
