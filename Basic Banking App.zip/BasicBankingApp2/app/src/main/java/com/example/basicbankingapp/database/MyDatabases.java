package com.example.basicbankingapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.basicbankingapp.data.Person;

import java.util.ArrayList;

public class MyDatabases extends SQLiteOpenHelper {

  public static final String DB_NAME = "persons";
  public static final int DB_VERSION =8;

  public static final String PERSON_TB_NAME = "person";
  public static final String PERSON_CL_NAME = "name";
  public static final String PERSON_CL_ID = "id";
  public static final String PERSON_CL_EMAIL = "email";
  public static final String PERSON_CL_CURRENT_BALANCE = "currentbalance";
  public static final String PERSON_CL_IMAGE = "image";
  public static final String PERSON_CL_NAME_SEND_MONEY = "namesendmoney";
  public static final String PERSON_CL_EMAIL_SEND_MONEY= "emailsendmoney";
  public static final String PERSON_CL_MONEY = "money";


  public MyDatabases(@Nullable Context context) {
    super(context, DB_NAME, null, DB_VERSION);
  }

  @Override
  public void onCreate(SQLiteDatabase db) {
    // this function call only one time when database is created
    db.execSQL(
        "create table "
            + PERSON_TB_NAME
            + " ("
            + PERSON_CL_ID
            + " integer primary key autoincrement ,"
            + PERSON_CL_NAME
            + " text, "
            + PERSON_CL_EMAIL
            + " text, "
            + PERSON_CL_CURRENT_BALANCE
            + " real, "
            + PERSON_CL_IMAGE
            +" integer, "
            +PERSON_CL_NAME_SEND_MONEY
            +" text, "
            +PERSON_CL_EMAIL_SEND_MONEY
            +" text, "
            +PERSON_CL_MONEY
            +" text )");

  }

  @Override
  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    // it calls every time upgrade the database version
    db.execSQL("Drop table if exists " + PERSON_TB_NAME);
    onCreate(db);
  }

  //INSERT
  public boolean insertPerson(String name  ,String email ,int currentBalance,int img) {
    SQLiteDatabase db = getWritableDatabase();
    ContentValues contentValues = new ContentValues();
    contentValues.put(PERSON_CL_NAME, name);
    contentValues.put(PERSON_CL_CURRENT_BALANCE, currentBalance);
    contentValues.put(PERSON_CL_EMAIL, email);
    contentValues.put(PERSON_CL_IMAGE,img);
    long result = db.insert(PERSON_TB_NAME, null, contentValues);
    return result != -1;
  }
  //INSERT send money
  public boolean insertPersonSend(String name  ,String email ,int money) {
    SQLiteDatabase db = getWritableDatabase();
    ContentValues contentValues = new ContentValues();
    contentValues.put(PERSON_CL_NAME_SEND_MONEY, name);
    contentValues.put(PERSON_CL_EMAIL_SEND_MONEY, email);
    contentValues.put(PERSON_CL_MONEY,money);

    long result = db.insert(PERSON_TB_NAME, null, contentValues);
    return result != -1;
  }
  //EDIT
  public void updateCurrentBalance(int id ,int money) {
    SQLiteDatabase db = getWritableDatabase();
    ContentValues contentValues = new ContentValues();

    contentValues.put(PERSON_CL_CURRENT_BALANCE, money);

    String args[] = {id + ""};
    long result = db.update(PERSON_TB_NAME, contentValues, "id=?", args);
   close();
  }
    //DELETE
  public boolean deletePerson(String name) {
    SQLiteDatabase db = getWritableDatabase();
    String args[] = {"%" + name + "%"};
    long result = db.delete(PERSON_TB_NAME, "name like ?", args);
    return result > 0;
  }
  //GET ALL PERSONS
  public ArrayList<Person> getAllPersons() {
    ArrayList<Person> persons = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor cursor = db.rawQuery("select * from " + PERSON_TB_NAME, null);

    if (cursor.moveToFirst()) {
      do {
        int id = cursor.getInt(0);
        String name = cursor.getString(1);
        String email = cursor.getString(2);
        int currentBalance = cursor.getInt(3);

        Person p = new Person(name, currentBalance, email);
        persons.add(p);

      } while (cursor.moveToNext());
      cursor.close();
    }
    return persons;
  }
  //SEARCH ABOUT ONE PRISON
  public ArrayList<Person> getPersons(String nameSearch) {
    ArrayList<Person> persons = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor cursor = db.rawQuery("select * from " + PERSON_TB_NAME+" where "+PERSON_CL_NAME+" like ?", new String[]{"%"+nameSearch+"%"});

    if (cursor.moveToFirst()) {
      do {
        int id = cursor.getInt(0);
        String name = cursor.getString(1);
        String email = cursor.getString(2);
        int currentBalance = cursor.getInt(3);

        Person p = new Person(name, currentBalance, email);
        persons.add(p);

      } while (cursor.moveToNext());
      cursor.close();
    }
    return persons;
  }

  public Cursor readAllData(){
    String query =" select * from "+PERSON_TB_NAME;
    SQLiteDatabase db =getReadableDatabase();
    Cursor cursor =null;
    if (db != null){
      cursor = db.rawQuery(query, null);
    }
    return  cursor;
  }
}
