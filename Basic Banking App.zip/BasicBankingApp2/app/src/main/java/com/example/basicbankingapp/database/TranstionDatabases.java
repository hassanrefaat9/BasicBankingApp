package com.example.basicbankingapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class TranstionDatabases extends SQLiteOpenHelper {

    public static final String DB_NAME = "Transtion";
    public static final int DB_VERSION =2;
    public static final String PERSON_TB_NAME = "transition";
    public static final String PERSON_CL_NAME_SEND_MONEY = "name";
    public static final String PERSON_CL_EMAIL_SEND_MONEY= "email";
    public static final String PERSON_CL_MONEY = "money";

    public TranstionDatabases(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table "
                        + PERSON_TB_NAME
                        + " ("
                        +PERSON_CL_NAME_SEND_MONEY
                        +" text, "
                        +PERSON_CL_EMAIL_SEND_MONEY
                        +" text, "
                        +PERSON_CL_MONEY
                        +" text )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists " + PERSON_TB_NAME);
        onCreate(db);
    }
    //INSERT send money
    public boolean insertPersonSend(String name  ,String email ,String money) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(PERSON_CL_NAME_SEND_MONEY, name);
        contentValues.put(PERSON_CL_EMAIL_SEND_MONEY, email);
        contentValues.put(PERSON_CL_MONEY,money);

        long result = db.insert(PERSON_TB_NAME, null, contentValues);
        return result != -1;
    }
    public Cursor readAllData(){
        String query =" select * from "+PERSON_TB_NAME;
        SQLiteDatabase db =getReadableDatabase();
        Cursor cursor =null;
        if (db != null){
            cursor = db.rawQuery(query, null);
        }
        return  cursor;
    }
}
