package com.example.basicbankingapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.basicbankingapp.R;

public class MainActivity extends AppCompatActivity {

  Animation tobAnim, bottomAnim;
  private static final int SPLASH_SCREEN = 3000;                        //Hassan Refaat
  ImageView splashScreenImage;                                          //Hassan Refaat
  TextView mainText, noticeText;                                        //Hassan Refaat

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // hide status bar
    getWindow()
        .setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    // hide action bar
    //getSupportActionBar().hide();
    setContentView(R.layout.activity_main);

    // animation
    Context context;
    tobAnim = AnimationUtils.loadAnimation(this, R.anim.top_anim);
    bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_anim);

    // hooks
    splashScreenImage = findViewById(R.id.splash_screen_image);
    mainText = findViewById(R.id.splash_screen_main_tv);
    noticeText = findViewById(R.id.splash_screen_tv_notion);

    splashScreenImage.setAnimation(tobAnim);
    mainText.setAnimation(bottomAnim);
    noticeText.setAnimation(bottomAnim);
    // splashScreen
    new Handler()
        .postDelayed(
            new Runnable() {
              @Override
              public void run() {
                Intent intent = new Intent(MainActivity.this, MainScreen.class);
                startActivity(intent);
                finish();
              }
            },
            SPLASH_SCREEN);
  }
}
