package com.example.basicbankingapp.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.basicbankingapp.adapter.CustomAdapter;
import com.example.basicbankingapp.data.Person;
import com.example.basicbankingapp.database.MyDatabases;
import com.example.basicbankingapp.adapter.OnRecyclerViewItemClickListener;
import com.example.basicbankingapp.R;

import java.util.ArrayList;

public class MainScreen extends AppCompatActivity implements OnRecyclerViewItemClickListener {
  // extra variables
  public static final String NAME = "name";
  public static final String IMAGE = "image";
  public static final String CURRENT_BALANCE = "currentBalance";
  public static final String EMAIL = "email";
  public static final String ID = "id";

  CustomAdapter adapter;
  MyDatabases db;
  // array list to fetch data from database ;
  public static ArrayList<String> names, emails ;
  public static ArrayList<Integer> currentBalances, images ,ids;

  private Toolbar toolbar;
  RecyclerView recyclerView;

  Button btnShow;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_main_screen);
    toolbar = findViewById(R.id.toolbar);
    setSupportActionBar(toolbar);
    recyclerView = findViewById(R.id.main_screen_recyclerView);

    // database access
    db = new MyDatabases(this);
    names = new ArrayList<>();
    emails = new ArrayList<>();
    images = new ArrayList<>();
    ids = new ArrayList<>();
    currentBalances = new ArrayList<>();

    db.insertPerson("Hassan Refaat", "hassab@gmail.com", 1000, R.drawable.profileimage);
    db.insertPerson("Abdo ali", "abdo.ali23@gmail.com", 2000, R.drawable.i2);
    db.insertPerson("Mohamed Refaat", "Refaat323@gmail.com", 3000, R.drawable.i3);
    db.insertPerson("Anas Mohamed", "AnasMohamed@gmail.com", 4000, R.drawable.i4);
    db.insertPerson(" Albra Mohamed", "Albra23@gmail.com", 5000, R.drawable.i5);
    db.insertPerson("Ahmed syaed", "syaed@gmail.com", 6000, R.drawable.i1);
    db.insertPerson("Hazem mohamed", "Hazem@gmail.com", 6666, R.drawable.i6);
    db.insertPerson("Anas Mohamed", "AnasMohamed@gmail.com", 3333, R.drawable.i4);
    db.insertPerson(" Albra Mohamed", "Albra23@gmail.com", 4444, R.drawable.i5);
    db.insertPerson("Ahmed syaed", "syaed@gmail.com", 5555, R.drawable.i1);
    db.insertPerson("Hazem mohamed", "Hazem@gmail.com", 6666, R.drawable.i6);

    storeDataInArrays();
       adapter =
        new CustomAdapter(
            names,
            emails,
            currentBalances,
            images,ids,
            new OnRecyclerViewItemClickListener() {
              @Override
              public void onItemClick(int position) {
                Intent intent = new Intent(getBaseContext(), Profileactivity.class);
                Toast.makeText(getBaseContext(), names.get(position) + "", Toast.LENGTH_LONG)
                    .show();
                intent.putExtra(NAME, names.get(position));
                intent.putExtra(CURRENT_BALANCE, currentBalances.get(position));
                intent.putExtra(IMAGE, images.get(position));
                intent.putExtra(EMAIL, emails.get(position));
                intent.putExtra(ID, ids.get(position));
                startActivity(intent);
              }
            });

    RecyclerView.LayoutManager lm = new LinearLayoutManager(this);

    recyclerView.setHasFixedSize(true);
    recyclerView.setLayoutManager(lm);
    recyclerView.setAdapter(adapter);

    btnShow = findViewById(R.id.button2);
    btnShow.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Intent intent = new Intent(getBaseContext(),ShowTransfers.class);
        startActivity(intent);
      }
    });
  }

  @Override
  public void onItemClick(int position) {}

  // make menu

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.main_menu, menu);

    SearchView searchView = (SearchView) menu.findItem(R.id.menu_search).getActionView();
    searchView.setSubmitButtonEnabled(true);

    searchView.setOnQueryTextListener(
        new SearchView.OnQueryTextListener() {
          @Override
          public boolean onQueryTextSubmit(String query) {

            return false;
          }

          @Override
          public boolean onQueryTextChange(String newText) {
            return false;
          }
        });

    return true;
  }

  @Override
  public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    return super.onOptionsItemSelected(item);
  }

  void storeDataInArrays() {
    Cursor cursor = db.readAllData();
    if (cursor.getCount() == 0) {
      Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
    } else {
      while (cursor.moveToNext()) {
        ids.add(cursor.getInt(0));
        names.add(cursor.getString(1));
        emails.add(cursor.getString(2));
        currentBalances.add(cursor.getInt(3));
        images.add(cursor.getInt(4));
      }
    }
  }
}
