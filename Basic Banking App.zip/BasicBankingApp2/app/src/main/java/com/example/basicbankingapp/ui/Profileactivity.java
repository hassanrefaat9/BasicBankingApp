package com.example.basicbankingapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.basicbankingapp.databinding.ActivityProfileactivityBinding;

public class Profileactivity extends AppCompatActivity {
    ActivityProfileactivityBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileactivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String name = getIntent().getStringExtra(MainScreen.NAME);
        int currentBalance = getIntent().getIntExtra(MainScreen.CURRENT_BALANCE,0);
        int image = getIntent().getIntExtra(MainScreen.IMAGE,0);
        String email = getIntent().getStringExtra(MainScreen.EMAIL);
        int id =getIntent().getIntExtra(MainScreen.ID,0);
        binding.profileScreenImage.setImageResource(image);
        binding.profileScreenTvName.setText(name);
        binding.profileMatrileTvName.setText(name);
        binding.profileScreenTvSmailName.setText(name);
        binding.currentBalanc.setText(currentBalance+"");
        binding.profileMatrileTvEmail.setText(email);
    binding.transferMonney.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {
            Intent intent = new Intent(getBaseContext(), TransferMonneyScreen.class);
            intent.putExtra(MainScreen.NAME, name);
            intent.putExtra(MainScreen.CURRENT_BALANCE, currentBalance);
            intent.putExtra(MainScreen.EMAIL, email);
            intent.putExtra(MainScreen.ID, id);
            startActivity(intent);
          }
        });
    }
}