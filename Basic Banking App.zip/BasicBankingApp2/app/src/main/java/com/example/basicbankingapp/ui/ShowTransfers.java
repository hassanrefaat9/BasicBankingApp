package com.example.basicbankingapp.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.basicbankingapp.R;
import com.example.basicbankingapp.adapter.ShowTransfersAdapter;
import com.example.basicbankingapp.database.MyDatabases;
import com.example.basicbankingapp.database.TranstionDatabases;

import java.util.ArrayList;

public class ShowTransfers extends AppCompatActivity {
    TextView tv_name,tv_email,tv_money;
    RecyclerView recyclerView ;
    public ArrayList<String>name,email,money;
    ShowTransfersAdapter adapter ;
    TranstionDatabases db ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_transfers);

        db =new TranstionDatabases(this);
        tv_name = findViewById(R.id.showtransfers_tv_name);
        tv_email = findViewById(R.id.showtransfers_tv_email);
        tv_money = findViewById(R.id.showtransfers_tv_money);

        name = new ArrayList<>();
        email =new ArrayList<>();
        money =new ArrayList<>();

        storeDataInArrays();
        recyclerView =findViewById(R.id.showtransfers_rc);

        adapter =new ShowTransfersAdapter(name,email,money);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(lm);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);


    }

    void storeDataInArrays() {
        Cursor cursor = db.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                name.add(cursor.getString(0));
                email.add(cursor.getString(1));
                money.add(cursor.getString(2));
            }
        }
    }
}