package com.example.basicbankingapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.basicbankingapp.database.MyDatabases;
import com.example.basicbankingapp.R;
import com.example.basicbankingapp.database.TranstionDatabases;

public class TransferMonneyScreen extends AppCompatActivity {
  TextView et_name, et_money;
  Button btn;
  TranstionDatabases db1;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_transfer_monney_screen);

    et_name = findViewById(R.id.transfermonneyscreen_tv_name);
    et_money = findViewById(R.id.transfer_monney);
    btn = findViewById(R.id.button);
    int id = getIntent().getIntExtra(MainScreen.ID, 0);
    String email = getIntent().getStringExtra(MainScreen.EMAIL);

    btn.setOnClickListener(
        new View.OnClickListener() {
          @Override
          public void onClick(View v) {

            String name = et_name.getText().toString();
            String stringMoney = et_money.getText().toString();

            int money = Integer.parseInt(stringMoney);
            int currentM = MainScreen.currentBalances.get(id-1);
            int total = money+currentM;

            if (MainScreen.names.get(id - 1).equals(name)) {
               db1 = new TranstionDatabases(getBaseContext());
              db1.getWritableDatabase();
              db1.insertPersonSend(name,email,money+"");
              db1.close();

              MyDatabases db2 = new MyDatabases(getBaseContext());
              db2.getWritableDatabase();
              db2.updateCurrentBalance(id, total);
              Toast.makeText(getBaseContext(), "Money has been sent", Toast.LENGTH_SHORT).show();
              Intent intent = new Intent(getBaseContext(),MainScreen.class);
              intent.putExtra("name",name);
              intent.putExtra("email",email);
              intent.putExtra("money",money+"");
              startActivity(intent);

            } else {
              Toast.makeText(
                      getBaseContext(),
                      "you cant send money to " + " " + name + " " + MainScreen.names.get(id-1),
                      Toast.LENGTH_SHORT)
                  .show();
            }
          }
        });
  }
}
